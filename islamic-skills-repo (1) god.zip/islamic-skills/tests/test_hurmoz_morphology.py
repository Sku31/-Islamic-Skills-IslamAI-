"""
Unit test for Layer A (hurmoz.git): Linguistic & Morphological Precision
"""
import unittest
from mcp_server.tools.morphology_hurmoz import morphology_lookup, root_concordance

class TestHurmozMorphology(unittest.TestCase):
    def test_root_patterns_distinction(self):
        res = root_concordance("g-f-r")
        self.assertIn("details", res)
        patterns = res["details"]["patterns"]
        
        self.assertIn("Ghafir", patterns)
        self.assertIn("Ghaffar", patterns)
        self.assertIn("Ghafur", patterns)
        
        # Verify grammatical weights
        self.assertEqual(patterns["Ghafir"]["weight"], "Fa'il (فَاعِل)")
        self.assertEqual(patterns["Ghaffar"]["weight"], "Fa''al (فَعَّال)")
        self.assertEqual(patterns["Ghafur"]["weight"], "Fa'ul (فَعُول)")

    def test_concordance_samples(self):
        res = root_concordance("q-l-b")
        self.assertIn("occurrences_sample", res)
        self.assertTrue(len(res["occurrences_sample"]) > 0)

if __name__ == "__main__":
    unittest.main()
