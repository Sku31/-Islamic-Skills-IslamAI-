"""
Unit test for Layer B (IslamAI.git): Selection Gate & Tafsir Depth
"""
import unittest
from mcp_server.tools.tafsir_islamai import fetch_tafsir, list_editions

class TestIslamAITafsir(unittest.TestCase):
    def test_selection_gate_enforcement(self):
        # Must fail when edition is omitted or invalid
        with self.assertRaises(ValueError) as ctx:
            fetch_tafsir(9, 6, edition="invalid-mufassir", nonce="QAI-TEST")
        self.assertIn("Selection Gate Violation", str(ctx.exception))

    def test_valid_tafsir_retrieval(self):
        res = fetch_tafsir(9, 6, edition="ibn-kathir", nonce="QAI-TEST")
        self.assertEqual(res["edition"], "ibn-kathir")
        self.assertIn("tafsir_text", res)
        self.assertTrue(res["nonce_verified"])

    def test_list_editions(self):
        editions = list_editions("tafsir")
        ids = [e["id"] for e in editions]
        self.assertIn("ibn-kathir", ids)
        self.assertIn("al-qurtubi", ids)
        self.assertIn("al-tabari", ids)

if __name__ == "__main__":
    unittest.main()
