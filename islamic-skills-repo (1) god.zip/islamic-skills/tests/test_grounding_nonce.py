"""
Unit test for Grounding Nonce and Receipt Validation
"""
import unittest
import importlib.util
import os
from mcp_server.tools.grounding import fetch_grounding_rules, validate_nonce

# Dynamically load receipt validator from skills/islamic-skills/scripts/receipt_validator.py
validator_path = os.path.join(os.path.dirname(__file__), "..", "scripts", "receipt_validator.py")
if not os.path.exists(validator_path):
    validator_path = os.path.join(os.path.dirname(__file__), "..", "skills", "islamic-skills", "scripts", "receipt_validator.py")
spec = importlib.util.spec_from_file_location("receipt_validator", validator_path)
validator_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator_mod)
validate_receipt_yaml = validator_mod.validate_receipt_yaml

class TestGroundingNonce(unittest.TestCase):
    def test_nonce_generation_and_validation(self):
        res = fetch_grounding_rules("test_agent")
        self.assertIn("nonce", res)
        nonce = res["nonce"]
        self.assertTrue(nonce.startswith("QAI-"))
        self.assertTrue(validate_nonce(nonce))
        self.assertFalse(validate_nonce(""))
        self.assertFalse(validate_nonce("invalid-nonce"))

    def test_receipt_validator(self):
        sample = """---
source: "quran.ai"
surah: 9
ayah: 6
translation_edition: "sahih-international"
nonce: "QAI-TEST12345"
verification_status: "canonical-verified"
---
Test text.
"""
        v = validate_receipt_yaml(sample)
        self.assertTrue(v["valid"])
        self.assertEqual(v["receipt"]["surah"], 9)
        self.assertEqual(v["receipt"]["ayah"], 6)

if __name__ == "__main__":
    unittest.main()
