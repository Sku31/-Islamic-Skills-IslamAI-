"""
Unit test for Layer C (aslam.git): Structural Navigation & Surah Discourse
"""
import unittest
from mcp_server.tools.navigation_aslam import structural_navigation, fetch_quran_metadata

class TestAslamNavigation(unittest.TestCase):
    def test_surah_9_discourse_architecture(self):
        res = structural_navigation(9, 1, 14)
        self.assertEqual(res["surah"], 9)
        self.assertIn("phases", res)
        self.assertEqual(len(res["phases"]), 5)
        
        # Verify 5 phases
        phase_names = [p["section_title"] for p in res["phases"]]
        self.assertIn("Declaration of Dissolution (Bara'ah)", phase_names)
        self.assertIn("The Exception Clause", phase_names)
        self.assertIn("The Ultimatum & War Condition", phase_names)
        self.assertIn("The Universal Political Asylum Mandate", phase_names)
        self.assertIn("Jurisprudential Rationale", phase_names)

    def test_metadata_indexing(self):
        meta = fetch_quran_metadata(9, 6)
        self.assertIn("juz", meta)
        self.assertIn("hizb", meta)
        self.assertIn("ruku", meta)
        self.assertIn("page", meta)
        self.assertEqual(meta["revelation_type"], "Madani")

if __name__ == "__main__":
    unittest.main()
