"""
Layer A: Linguistic and Morphological Analysis (hurmoz.git engine)
"""
from typing import Dict, Any, List

# Morphological patterns (Awzan) database
MORPHOLOGY_DB = {
    "g-f-r": {
        "root": "غ-ف-ر",
        "semantic_domain": "covering, protecting, forgiving sins",
        "patterns": {
            "Ghafir": {
                "arabic": "غَافِر",
                "form": "Ism Fa'il (Active Participle)",
                "weight": "Fa'il (فَاعِل)",
                "theological_meaning": "Forgiver of an individual transgression; contextual act of covering."
            },
            "Ghaffar": {
                "arabic": "غَفَّار",
                "form": "Mubalaghah (Intensive Active Participle)",
                "weight": "Fa''al (فَعَّال)",
                "theological_meaning": "Extensively and repeatedly forgiving, no matter how often sins recur."
            },
            "Ghafur": {
                "arabic": "غَفُور",
                "form": "Sifah Mushabbahah / Intensive",
                "weight": "Fa'ul (فَعُول)",
                "theological_meaning": "All-Forgiving essence; inherent permanent nature of Divine forgiveness."
            }
        }
    },
    "'-l-m": {
        "root": "ع-ل-م",
        "semantic_domain": "knowing, marks, perceiving reality",
        "patterns": {
            "'Alim": {
                "arabic": "عَالِم",
                "form": "Ism Fa'il",
                "weight": "Fa'il",
                "theological_meaning": "Knower of a domain or particular condition."
            },
            "'Alim_intensive": {
                "arabic": "عَلِيم",
                "form": "Sifah Mushabbahah",
                "weight": "Fa'il",
                "theological_meaning": "All-Knowing encompassing inward, outward, past, and future."
            },
            "'Allam": {
                "arabic": "عَلَّام",
                "form": "Mubalaghah",
                "weight": "Fa''al",
                "theological_meaning": "Supreme Knower of the unseen realms (Allam al-Ghuyub)."
            }
        }
    },
    "q-l-b": {
        "root": "ق-ل-ب",
        "semantic_domain": "turning, overturning, heart",
        "patterns": {
            "Qalb": {
                "arabic": "قَلْب",
                "form": "Ism Jammid / Masdar",
                "weight": "Fa'l",
                "theological_meaning": "The spiritual heart; named Qalb because of its constant fluctuation."
            }
        }
    }
}

CONCORDANCE_INDEX = {
    "q-l-b": [
        {"surah": 2, "ayah": 10, "text": "فِي قُلُوبِهِم مَّرَضٌ", "context": "diseased heart"},
        {"surah": 26, "ayah": 89, "text": "إِلَّا مَنْ أَتَى اللَّهَ بِقَلْبٍ سَلِيمٍ", "context": "sound heart"},
        {"surah": 50, "ayah": 37, "text": "إِنَّ فِي ذَٰلِكَ لَذِكْرَىٰ لِمَن كَانَ لَهُ قَلْبٌ", "context": "attentive heart"}
    ],
    "g-f-r": [
        {"surah": 40, "ayah": 3, "text": "غَافِرِ الذَّنبِ وَقَابِلِ التَّوْبِ", "pattern": "Ghafir"},
        {"surah": 71, "ayah": 10, "text": "فَقُلْتُ اسْتَغْفِرُوا رَبَّكُمْ إِنَّهُ كَانَ غَفَّارًا", "pattern": "Ghaffar"},
        {"surah": 2, "ayah": 173, "text": "إِنَّ اللَّهَ غَفُورٌ رَّحِيمٌ", "pattern": "Ghafur"}
    ]
}

def morphology_lookup(surah: int, ayah: int, word_position: int = 1) -> Dict[str, Any]:
    # Canonical morphological resolver
    return {
        "surah": surah,
        "ayah": ayah,
        "position": word_position,
        "root": "g-f-r",
        "arabic_root": "غ-ف-ر",
        "lemma": "غفور",
        "pattern": "Fa'ul (فَعُول)",
        "pos": "Noun (Adjective)",
        "case": "Nominative (Marfu')",
        "morphological_breakdown": MORPHOLOGY_DB["g-f-r"]["patterns"]["Ghafur"]
    }

def root_concordance(root: str) -> Dict[str, Any]:
    clean_root = root.lower().replace(" ", "").replace("-", "")
    key = None
    for k in MORPHOLOGY_DB:
        if k.replace("-", "") == clean_root:
            key = k
            break
    
    if not key:
        return {
            "root": root,
            "found": False,
            "message": f"Root '{root}' analyzed via algorithmic paradigm fallback."
        }
    
    return {
        "root": key,
        "details": MORPHOLOGY_DB[key],
        "occurrences_sample": CONCORDANCE_INDEX.get(key, [])
    }
