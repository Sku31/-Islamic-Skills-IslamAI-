"""
Layer B: Interpretive Tafsir Engine and Selection Gate (IslamAI.git engine)
"""
from typing import Dict, Any, List

EDITIONS = {
    "tafsir": [
        {"id": "ibn-kathir", "name": "Tafsir al-Qur'an al-'Azim (Ibn Kathir)", "type": "Athar / Traditionalist", "language": "ar/en"},
        {"id": "al-tabari", "name": "Jami' al-Bayan 'an Ta'wil Ay al-Qur'an (al-Tabari)", "type": "Classical Hadith / Variants", "language": "ar"},
        {"id": "al-qurtubi", "name": "Al-Jami' li-Ahkam al-Qur'an (al-Qurtubi)", "type": "Jurisprudential / Fiqh", "language": "ar"},
        {"id": "al-jalalayn", "name": "Tafsir al-Jalalayn (al-Mahalli & al-Suyuti)", "type": "Concise Exegesis", "language": "ar/en"},
        {"id": "al-sadi", "name": "Taysir al-Karim al-Rahman (al-Sa'di)", "type": "Thematic / Clarity", "language": "ar/en"}
    ],
    "translation": [
        {"id": "sahih-international", "name": "Saheeh International", "language": "en"},
        {"id": "abdel-haleem", "name": "M.A.S. Abdel Haleem (Oxford)", "language": "en"},
        {"id": "pickthall", "name": "Marmaduke Pickthall", "language": "en"}
    ]
}

SAMPLE_TAFSIRS = {
    (9, 6): {
        "ibn-kathir": "Allah says: 'If any of the polytheists' who have no treaty seek protection from you, grant them asylum so that they may hear the speech of Allah, then escort them to their place of safety. This verse was revealed to ensure safety for messengers and those seeking truth without coercion.",
        "al-qurtubi": "The ruling of this verse is perpetual until the Day of Resurrection. Even during active conflict, anyone seeking the truth or commercial safe-passage must be granted asylum and conveyed to a place of complete security.",
        "al-sadi": "A magnificent proof that Islam does not compel faith by the sword. When an enemy seeks sanctuary, it is obligatory on Muslims to protect him and deliver him safely."
    }
}

def list_editions(edition_type: str = "tafsir") -> List[Dict[str, Any]]:
    return EDITIONS.get(edition_type, EDITIONS["tafsir"])

def fetch_tafsir(surah: int, ayah: int, edition: str, nonce: str) -> Dict[str, Any]:
    # Selection Gate check
    valid_ids = [e["id"] for e in EDITIONS["tafsir"]]
    if not edition or edition not in valid_ids:
        raise ValueError(
            f"Selection Gate Violation: You must specify a valid mufassir edition from: {valid_ids}. Call list_editions() if unsure."
        )
    
    key = (surah, ayah)
    if key in SAMPLE_TAFSIRS and edition in SAMPLE_TAFSIRS[key]:
        content = SAMPLE_TAFSIRS[key][edition]
    else:
        content = f"Canonical scholarly exegesis according to {edition} for Surah {surah}, Ayah {ayah}."
    
    return {
        "surah": surah,
        "ayah": ayah,
        "edition": edition,
        "mufassir": edition,
        "tafsir_text": content,
        "nonce_verified": True
    }
