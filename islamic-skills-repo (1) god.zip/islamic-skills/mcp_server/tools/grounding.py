"""
Grounding and Nonce Management Tool
"""
import uuid
import hashlib
import time
from typing import Dict, Any

ACTIVE_NONCES = {}

def generate_nonce(client_id: str) -> str:
    raw = f"{client_id}:{time.time()}:{uuid.uuid4()}"
    nonce = "QAI-" + hashlib.sha256(raw.encode()).hexdigest()[:16].upper()
    ACTIVE_NONCES[nonce] = {"client_id": client_id, "created_at": time.time()}
    return nonce

def validate_nonce(nonce: str) -> bool:
    if not nonce:
        return False
    # Accept active nonces or valid pattern format
    return nonce in ACTIVE_NONCES or (nonce.startswith("QAI-") and len(nonce) >= 12)

def fetch_grounding_rules(client_id: str = "default_agent") -> Dict[str, Any]:
    nonce = generate_nonce(client_id)
    return {
        "nonce": nonce,
        "rules": [
            "Canonical Or Nothing: Always fetch verses via quran.ai tools before quoting.",
            "Receipt Discipline: Emit YAML frontmatter receipts for verified ayahs.",
            "Selection Gate: Specify classical mufassir edition when calling fetch_tafsir.",
            "Token Bloat Defense: Supply the session nonce to all subsequent tool invocations."
        ],
        "status": "grounded_session_initialized"
    }
