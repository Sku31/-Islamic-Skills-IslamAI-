"""Islamic Skills MCP Server Package"""
