#!/usr/bin/env bash
# Script to launch vLLM with Islamic Skills tool calling enabled

MODEL_NAME=${1:-"meta-llama/Llama-3.1-8B-Instruct"}
PORT=${2:-8000}

echo "Starting vLLM OpenAI-compatible server with Islamic Skills..."
vllm serve "$MODEL_NAME" \
    --port "$PORT" \
    --enable-auto-tool-choice \
    --tool-call-parser hermes \
    --chat-template vllm/chat_template_hermes_toolcall.jinja \
    --tensor-parallel-size 1
