"""
vLLM / MCP Gateway Proxy
Bridges incoming user requests to vLLM and executes Islamic Skills MCP tools in an autonomous loop.
"""
import json
import requests
from skills.islamic_skills.scripts.quran_mcp_client import QuranMCPClient

def run_agent_loop(vllm_url: str, user_query: str):
    client = QuranMCPClient()
    nonce = client.initialize_grounding()
    print(f"Initialized Grounding Nonce: {nonce}")
    
    with open("schemas/openai_tools.json") as f:
        tools = json.load(f)
    with open("skills/islamic-skills/assets/system_prompt_fragment.md") as f:
        system_prompt = f.read()
        
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_query}
    ]
    
    # Send request to vLLM
    payload = {
        "model": "meta-llama/Llama-3.1-8B-Instruct",
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto"
    }
    print("Agent dispatched to vLLM endpoint...")
