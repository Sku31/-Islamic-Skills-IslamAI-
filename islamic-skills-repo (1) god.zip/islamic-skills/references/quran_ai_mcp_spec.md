# quran.ai MCP Framework Specification

The Model Context Protocol (MCP) server exposes precision tools for Quranic research:

1. `fetch_grounding_rules(client_id: str) -> dict`
   Returns grounding rules and a cryptographic session nonce.
2. `search_quran(query: str, language: str = "en") -> list[dict]`
   Performs semantic and lexical search across the Quran text.
3. `fetch_quran(surah: int, ayah: int, nonce: str) -> dict`
   Returns the canonical Arabic Uthmani text with diacritics.
4. `fetch_translation(surah: int, ayah: int, edition: str, nonce: str) -> dict`
   Returns verified translations (e.g. `sahih-international`, `abdel-haleem`).
5. `fetch_tafsir(surah: int, ayah: int, edition: str, nonce: str) -> dict`
   Returns classical tafsir commentary. Requires valid mufassir edition.
6. `fetch_quran_metadata(surah: int, ayah: int) -> dict`
   Returns Juz, Hizb, Page, Ruku, Revelation order, and Sajdah data.
7. `list_editions(type: str) -> list[dict]`
   Lists verified translations or tafsir editions.
8. `morphology_lookup(surah: int, ayah: int, word_position: int) -> dict`
   Returns root, lemma, grammatical case, and morphological pattern (awzan).
9. `root_concordance(root: str) -> list[dict]`
   Finds all occurrences of a tri-consonantal root across the Quran.
10. `structural_navigation(surah: int, ayah_start: int, ayah_end: int) -> dict`
    Returns thematic discourse segmentation and architectural units.
