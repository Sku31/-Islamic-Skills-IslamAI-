# Layer A: Linguistic and Morphological Precision (hurmoz.git)

## 1. Overview
Layer A provides the morphological engine for Islamic Skills, inspired by `hurmoz.git`. It treats Arabic as a root-and-pattern language where subtle shifts in verb forms and nominal derivations convey theological and jurisprudential nuances.

## 2. Morphological Distinctions
Consider root **Gh-F-R** (غ-ف-ر) expressing covering and forgiving:
- **Ghafir (غَافِر)**: Active participle (Ism Fa'il), pattern `Fa'il`. Denotes the one who forgives an individual act or in a particular instance (e.g., Surah Ghafir 40:3).
- **Ghaffar (غَفَّار)**: Intensive active noun (Mubalaghah), pattern `Fa''al`. Denotes repetitive, extensive, and frequent forgiveness regardless of frequency of transgression (e.g., Surah Nuh 71:10).
- **Ghafur (غَفُور)**: Deponent intensive adjective (Sifah Mushabbahah / Mubalaghah), pattern `Fa'ul`. Denotes an intrinsic, permanent attribute of Divine mercy that covers all sins (e.g., Surah al-Baqarah 2:173).

## 3. Paradigm Conjugation Mapping
Given a root like **‘-L-M** (ع-ل-م - knowledge):
- Form I (`'Alima / Ya'lamu`): To know directly.
- Form II (`'Allama / Yu'allimu`): To teach systematically (causative).
- Form V (`Ta'allama / Yata'allamu`): To learn iteratively.
- Form X (`Ista'lama / Yasta'limu`): To inquire or seek information.

## 4. Root Concordance
Concordance queries allow vertical thematic analysis across all 114 Surahs. For example, tracking the root **Q-L-B** (heart) across its 168 Quranic occurrences reveals the spiritual spectrum from *Qalb Salim* (sound heart) to *Qalb Marid* (diseased heart).
