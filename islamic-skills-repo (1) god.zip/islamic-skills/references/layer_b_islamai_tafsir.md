# Layer B: Interpretive and Tafsir Depth (IslamAI.git)

## 1. Overview
Layer B implements scholarly depth, derived from `IslamAI.git`. It ensures the AI never offers ungrounded personal exegesis.

## 2. Tafsir Modes
- **Single-Source Tafsir**: Quick lookup for lexical meaning, asbab al-nuzul (occasions of revelation), or direct verse meaning (e.g., Mukhtasar Tafsir Ibn Kathir, Tafsir al-Sa'di, or Tafsir al-Jalalayn).
- **Multi-Source Tafsir**: Required for legal verses (Ayat al-Ahkam), theological debates (Kalam/Aqidah), or ambiguous passages. Compares traditionalist (Ibn Kathir, al-Tabari), legalist (al-Qurtubi), and linguistic (al-Zamakhshari) commentaries.

## 3. The Selection Gate
The AI agent must never guess an interpretation without declaring its hermeneutic lens. The selection gate enforces that:
1. `list_editions` is verified or a canonical mufassir is explicitly named.
2. Supported editions:
   - `ibn-kathir`: Tafsir al-Qur'an al-'Azim (Athar-based, Hadith cross-referencing).
   - `al-tabari`: Jami' al-Bayan (Classical early consensus and variant transmissions).
   - `al-qurtubi`: Al-Jami' li-Ahkam al-Qur'an (Jurisprudential/Fiqh depth across madhahib).
   - `al-jalalayn`: Tafsir al-Jalalayn (Concise linguistic gloss).
   - `al-sadi`: Taysir al-Karim al-Rahman (Contemporary clear thematic exegesis).

## 4. AI Editorial Disclaimer
When synthesizing sources to address modern contexts (e.g., bioethics, AI ethics, modern finance), the agent must prepend or append:
> **AI Editorial Disclaimer:** The synthesis above is an analytical reasoning extrapolation. The classical authorities cited provided the foundational linguistic and legal principles; the contextual synthesis reflects AI analytical modeling.
