"""
Quran AI MCP Client Helper
Convenience wrapper to query the Islamic Skills MCP server.
"""

import json
import subprocess
from typing import Any, Dict, List, Optional

class QuranMCPClient:
    def __init__(self, server_script: str = "mcp_server/server.py"):
        self.server_script = server_script
        self.nonce: Optional[str] = None

    def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call a tool via the MCP server stdio interface."""
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments
            }
        }
        proc = subprocess.Popen(
            ["python3", self.server_script],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        stdout, stderr = proc.communicate(input=json.dumps(payload) + "\n")
        if proc.returncode != 0:
            raise RuntimeError(f"MCP server error: {stderr}")
        
        for line in stdout.strip().split("\n"):
            if not line:
                continue
            try:
                resp = json.loads(line)
                if "result" in resp:
                    return resp["result"]
            except json.JSONDecodeError:
                continue
        raise RuntimeError(f"No valid response from server: {stdout}")

    def initialize_grounding(self, client_id: str = "islamic-skills-agent") -> str:
        res = self.call_tool("fetch_grounding_rules", {"client_id": client_id})
        self.nonce = res.get("nonce")
        return self.nonce

    def get_verse(self, surah: int, ayah: int, edition: str = "sahih-international") -> Dict[str, Any]:
        if not self.nonce:
            self.initialize_grounding()
        arabic = self.call_tool("fetch_quran", {"surah": surah, "ayah": ayah, "nonce": self.nonce})
        trans = self.call_tool("fetch_translation", {"surah": surah, "ayah": ayah, "edition": edition, "nonce": self.nonce})
        meta = self.call_tool("fetch_quran_metadata", {"surah": surah, "ayah": ayah})
        return {
            "surah": surah,
            "ayah": ayah,
            "arabic": arabic.get("text"),
            "translation": trans.get("text"),
            "metadata": meta
        }
