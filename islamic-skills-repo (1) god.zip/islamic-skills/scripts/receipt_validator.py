"""
Receipt Validator Script
Validates Quranic Grounding receipts in markdown / YAML format.
"""

import re
import sys
import yaml

RECEIPT_REGEX = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

REQUIRED_FIELDS = [
    "source",
    "surah",
    "ayah",
    "translation_edition",
    "nonce",
    "verification_status"
]

def validate_receipt_yaml(content: str) -> dict:
    match = RECEIPT_REGEX.search(content.strip())
    if not match:
        return {"valid": False, "error": "No YAML frontmatter receipt found."}
    
    yaml_text = match.group(1)
    try:
        data = yaml.safe_load(yaml_text)
    except Exception as e:
        return {"valid": False, "error": f"Invalid YAML: {str(e)}"}
    
    missing = [f for f in REQUIRED_FIELDS if f not in data]
    if missing:
        return {"valid": False, "error": f"Missing required fields: {missing}"}
    
    if data.get("verification_status") != "canonical-verified":
        return {"valid": False, "error": "Status is not canonical-verified"}
    
    return {"valid": True, "receipt": data}

if __name__ == "__main__":
    test_yaml = """---
source: "quran.ai"
surah: 9
ayah: 6
translation_edition: "sahih-international"
nonce: "TEST-NONCE"
verification_status: "canonical-verified"
---
And if any one of the polytheists seeks your protection, then grant him protection...
"""
    res = validate_receipt_yaml(test_yaml)
    print("Self-test result:", res)
