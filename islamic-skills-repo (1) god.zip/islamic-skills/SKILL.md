---
name: islamic-skills
description: Canonical Quranic and Islamic knowledge retrieval, morphology analysis, tafsir commentary, and structural navigation using quran.ai MCP, hurmoz, IslamAI, and aslam frameworks. Use when answering questions about the Quran, verses, Arabic root morphology, tafsir, or Islamic jurisprudence where precision and verifiable grounding receipts are required.
---
# Islamic Skills (IslamAI)

A precision-engineered tiered architectural skill combining canonical Quran retrieval, root-lemma morphology (hurmoz.git), multi-source tafsir commentary (IslamAI.git), and structural Mushaf navigation (aslam.git) via the quran.ai MCP framework.

## Summary

This skill transforms Quranic and Islamic knowledge inquiry from speculative language model guessing into an auditable science of canonical retrieval and structured interpretation. It enforces a strict "Canonical Or Nothing" philosophy where every quoted ayah requires an explicit tool receipt and grounding nonce.

## When to Use

Activate this skill whenever:

- Inquiring about specific Quranic verses, surahs, or textual passages.
- Performing Arabic root morphology, lemma breakdown, or pattern (awzan) analysis.
- Requesting tafsir commentary across classical authorities (Ibn Kathir, al-Tabari, al-Qurtubi, al-Jalalayn, al-Sa'di).
- Analyzing the structural discourse, thematic division, or legal-diplomatic architecture of a passage.
- Navigating the Mushaf by Juz, Page, Hizb, or Ruku without re-reading entire texts.
- Requiring verifiable citations with YAML frontmatter receipts and AI editorial disclaimers.

## Core Philosophy: Canonical Or Nothing

Unverified memory is merely a suggestion. Every Quranic claim must be backed by a verified retrieval receipt.

- Context-First Workflow: Always query tools before generating Quranic commentary. Check existing conversation receipts before fetching new data.
- The Grounding Nonce: Use `fetch_grounding_rules` at the start of a session. Capture the returned session nonce. Pass this nonce to subsequent calls to suppress redundant rule dumps and prevent token bloat.
- Grounding Receipts: All verse citations must be rendered with a structured YAML frontmatter block detailing surah, ayah, arabic text, translation edition, and verification hash.

## The Three-Tiered Skill Architecture

### Layer A: Linguistic and Morphological Precision (hurmoz.git)

Focus on the micro view of Quranic vocabulary:

- Morphology: Differentiate nuanced morphological patterns (awzan). For example, distinguish between Ghafir (active participle - forgiver), Ghaffar (intensive fa'al - frequent forgiver), and Ghafur (inherent deponent fa'ul - all-forgiving essence).
- Paradigm: Map lemma families. Show how a single tri-consonantal root generates semantic variations across different surahs.
- Concordance: Trace root occurrences vertically across the entire Mushaf to analyze thematic consistency.

### Layer B: Interpretive and Tafsir Depth (IslamAI.git)

Focus on the macro view of scholarly interpretation:

- Tafsir Discipline: Differentiate between Single-Source Tafsir (rapid linguistic or factual clarification) and Multi-Source Tafsir (deep theological, jurisprudential, or comparative exegesis).
- The Selection Gate: Never generate an interpretive commentary without passing through the selection gate. Explicitly specify the mufassir edition or invoke `list_editions` to ground the perspective.
- Comparative Balance: When verses have differing scholarly opinions, present multi-source viewpoints neutrally and cite each source edition.

### Layer C: Structural and Navigational Logic (aslam.git)

Focus on the spatial view and discourse architecture of the Mushaf:

- Structural Context: Analyze passages as cohesive discourse units rather than isolated fragments. For example, analyze Surah at-Tawbah (9:1-14) as an integrated legal-diplomatic treaty document (Declaration -> Exception -> Deadline -> Asylum).
- Metadata Mastery: Navigate the Mushaf efficiently by Juz, Page, Hizb, and Ruku using `fetch_quran_metadata` to anchor verses spatially without costly full-text scans.

## Operational Workflow: The Four-Stage Execution Loop

Follow this sequence for every inquiry:

1. Search Broadly: Invoke `search_quran` or `search_tafsir` to locate candidate verses or themes.
2. Fetch Selectively: Shortlist 3 to 7 candidate verses. Call `fetch_translation` or `fetch_quran` with the session nonce to obtain canonical precision.
3. Ground Deeply: Call `fetch_tafsir` with the selected mufassir edition to incorporate scholarly exegesis.
4. Synthesize and Disclaim: Combine de-duplicated sources into a final synthesis. If an inference or modern application is not explicitly stated in the classical text, append an AI Editorial Disclaimer.

## Grounding Receipt Format

When presenting verified verses, include the YAML receipt block:

```yaml
---
source: "quran.ai"
surah: 9
ayah: 6
root: "j-w-r"
edition: "sahih-international"
mufassir: "ibn-kathir"
nonce: "GROUNDING-NONCE-HASH"
status: "canonical-verified"
---
```

Followed immediately by the Arabic text, English translation, and scholarly commentary.

## Gotchas and Edge Cases

- Never extrapolate unstated rulings: If classical tafsir does not explicitly state a modern analogy, label the thought clearly as an AI Editorial Disclaimer.
- Always check the Grounding Nonce: Do not trigger repetitive grounding rule fetches if a nonce has already been established in the current conversation.
- Respect the Selection Gate: Failing to specify an edition in `fetch_tafsir` will result in a validation gate error. Always query `list_editions` if unsure.
