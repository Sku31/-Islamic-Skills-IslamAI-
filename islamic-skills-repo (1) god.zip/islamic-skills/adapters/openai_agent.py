"""
OpenAI & vLLM Client Adapter for Islamic Skills
"""
import os
import json
from mcp_server.tools.grounding import fetch_grounding_rules
from mcp_server.tools.morphology_hurmoz import morphology_lookup, root_concordance
from mcp_server.tools.tafsir_islamai import list_editions, fetch_tafsir
from mcp_server.tools.navigation_aslam import structural_navigation, fetch_quran_metadata

DISPATCH_MAP = {
    "fetch_grounding_rules": fetch_grounding_rules,
    "morphology_lookup": morphology_lookup,
    "root_concordance": root_concordance,
    "list_editions": list_editions,
    "fetch_tafsir": fetch_tafsir,
    "structural_navigation": structural_navigation,
    "fetch_quran_metadata": fetch_quran_metadata
}

class IslamicSkillsOpenAIAgent:
    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "dummy")
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL", "http://localhost:8000/v1")
        with open("schemas/openai_tools.json") as f:
            self.tools = json.load(f)

    def execute_tool_call(self, tool_name: str, arguments: dict):
        fn = DISPATCH_MAP.get(tool_name)
        if not fn:
            return {"error": f"Tool {tool_name} not found"}
        return fn(**arguments)
