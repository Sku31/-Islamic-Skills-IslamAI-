"""Client Adapters for Islamic Skills"""
