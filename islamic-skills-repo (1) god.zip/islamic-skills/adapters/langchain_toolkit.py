"""
LangChain Toolkit for Islamic Skills
"""
from typing import Optional
from mcp_server.tools.grounding import fetch_grounding_rules
from mcp_server.tools.morphology_hurmoz import morphology_lookup, root_concordance
from mcp_server.tools.tafsir_islamai import fetch_tafsir, list_editions
from mcp_server.tools.navigation_aslam import structural_navigation, fetch_quran_metadata

class IslamicSkillsToolkit:
    @staticmethod
    def get_tools():
        # Returns callables compatible with LangChain StructuredTool
        return [
            fetch_grounding_rules,
            morphology_lookup,
            root_concordance,
            fetch_tafsir,
            list_editions,
            structural_navigation,
            fetch_quran_metadata
        ]
